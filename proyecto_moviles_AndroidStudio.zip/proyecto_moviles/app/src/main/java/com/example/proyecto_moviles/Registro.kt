package com.example.proyecto_moviles

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class Registro : AppCompatActivity() {
    var ID:EditText?=null
    var nombre:EditText?=null
    var apellidos:EditText?=null
    var password:EditText?=null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_registro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        ID = findViewById(R.id.ID)
        nombre = findViewById(R.id.nombre)
        apellidos = findViewById(R.id.lastname)
        password = findViewById(R.id.editTextTextPassword)

    }
    fun clickBtnInsertar(view:View){
        if (ID?.text.isNullOrEmpty() || nombre?.text.isNullOrEmpty() || apellidos?.text.isNullOrEmpty() || password?.text.isNullOrEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_LONG).show()
            return
        }

        //val URL= "http://192.168.100.38/Proyecto_moviles/registro.php"
        val URL= "http://172.21.232.56/Proyecto_moviles/registro.php"
        val cola: RequestQueue = Volley.newRequestQueue(this)
        val resultadoPost = object : StringRequest(Request.Method.POST, URL,

            Response.Listener<String> { response ->
                Toast.makeText(this, "Usuario insertado exitosamente", Toast.LENGTH_LONG).show()
                val back = Intent(this, MainActivity::class.java)
                startActivity(back) // Iniciar la nueva actividad
                finish()

            }, Response.ErrorListener { error ->
                Toast.makeText(this, "Error $error", Toast.LENGTH_LONG).show()
            }
        ){
            override fun getParams(): MutableMap<String, String>? {
               val parametros = HashMap<String, String>()
               parametros.put("ID", ID?.text.toString())
                parametros.put("nombre", nombre?.text.toString())
                parametros.put("apellidos", apellidos?.text.toString())
                parametros.put("pass", password?.text.toString())
                return parametros
            }
        }
        cola.add(resultadoPost)
    }
}
