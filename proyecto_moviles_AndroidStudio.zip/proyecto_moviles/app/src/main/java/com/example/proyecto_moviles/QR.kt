package com.example.proyecto_moviles

import android.os.Bundle
import android.util.Size
import android.view.PixelCopy.Request
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.proyecto_moviles.databinding.ActivityQrBinding
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScanning
import java.util.concurrent.Executor
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import android.Manifest
import android.content.Intent
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.common.util.concurrent.ListenableFuture
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class QR : AppCompatActivity() {
    private lateinit var binding: ActivityQrBinding

    private lateinit var cameraExecutor: ExecutorService

    private lateinit var barcodeScanner: BarcodeScanner
    private var lastDate: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityQrBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor= Executors.newSingleThreadExecutor()
        barcodeScanner =BarcodeScanning.getClient()

        val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()){
            isGranted ->
            if(isGranted) {
                startCamera()
            }else{
                Toast.makeText(this, "Permisos de la camára necesarios", Toast.LENGTH_LONG).show()
            }
        }
        requestPermissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera(){
        val cameraProviderFuture= ProcessCameraProvider.getInstance(this)
        val screenSize = Size(1280, 720)
        val resolutionSelector = ResolutionSelector.Builder().setResolutionStrategy(
            ResolutionStrategy(screenSize, ResolutionStrategy.FALLBACK_RULE_NONE)
        ).build()

        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            cameraProvider.unbindAll()
            val preview = Preview.Builder().setResolutionSelector(resolutionSelector)
                .build()
                .also {
                    it.setSurfaceProvider(binding.previewView.surfaceProvider)
                }

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, { imageProxy ->
                        processImageProxy(imageProxy)
                    })
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
            cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalyzer)
        }, ContextCompat.getMainExecutor(this))

    }

    @OptIn(ExperimentalGetImage::class)
    private fun processImageProxy(imageProxy: ImageProxy){
        val mediaImage = imageProxy.image

        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)

            barcodeScanner.process(image)
                .addOnSuccessListener { barcodes ->
                    for (barcode in barcodes) {
                        handleBarcode(barcode)
                    }
                }
                .addOnFailureListener {
                    //binding.resultTextview.text="Fallo al escanear el código"
                    Toast.makeText(this, "Fallo al escanear el código", Toast.LENGTH_LONG).show()
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        }
    }

    private fun handleBarcode(barcode:Barcode){
        val txt = barcode.url ?.url ?: barcode.displayValue
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        val dateOnly = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if(txt != null){

            val parts = txt.split(" ", limit = 2)
            val id = parts[0]  // Extraer ID
            val nombre = parts.getOrElse(1) { "Nombre no disponible" }

            binding.resultTextview.text = "ID: $id\nNombre: $nombre"

            if (dateOnly == lastDate) {
                return
            }
            lastDate = dateOnly


            //val url= "http://192.168.100.38/Proyecto_moviles/asistencia.php"
            val url= "http://172.21.232.56/Proyecto_moviles/asistencia.php"
            val col: RequestQueue = Volley.newRequestQueue(this)

            val valpost  = object : StringRequest(com.android.volley.Request.Method.POST, url,
                Response.Listener<String> { response ->
                    try{
                        // Depurar el contenido de la respuesta
                        val jsonResponse = JSONObject(response)
                        val success = jsonResponse.getBoolean("success")
                        if(success){
                            //val principal = Intent(this, Principal::class.java)
                            //startActivity(principal) // Iniciar la nueva actividad
                            Toast.makeText(this, "Ha tomado asistencia correctamente", Toast.LENGTH_LONG).show()
                            finish()
                        }else{
                            Toast.makeText(this, "Ya habia tomado su asistencia anteriormente", Toast.LENGTH_LONG).show()
                            finish()
                        }

                    }catch (e : Exception){
                        Toast.makeText(this, "Error al tomar asistencia", Toast.LENGTH_LONG).show()
                    }
                }, Response.ErrorListener { error ->
                    Toast.makeText(this, "Error $error", Toast.LENGTH_LONG).show()
                }
            ) {
                override fun getParams(): Map<String, String>? {
                    return mapOf(
                        "ID" to id,
                        "nombre" to nombre,
                        "fecha" to  timestamp
                    )
                }
            }
            col.add(valpost)
        }else{
            binding.resultTextview.text="No se detecto el código"
        }

    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }

}