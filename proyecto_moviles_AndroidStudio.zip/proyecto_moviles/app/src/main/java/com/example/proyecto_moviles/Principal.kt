package com.example.proyecto_moviles

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton

class Principal : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }
        val btnAsistencia= findViewById<FloatingActionButton>(R.id.btnAsistencia)
        btnAsistencia.setOnClickListener{
            val open= Intent(this, QR::class.java)
            startActivity(open)
        }

        val btnVisualizarLista =findViewById<FloatingActionButton>(R.id.btnVisualizarLista)
        btnVisualizarLista.setOnClickListener{
            val open1= Intent(this, Lista::class.java)
            startActivity(open1)
        }

        val btnSalir= findViewById<Button>(R.id.btnSalir)
        btnSalir.setOnClickListener{
            val op = Intent(this, MainActivity::class.java)
            startActivity(op)
        }
    }
}