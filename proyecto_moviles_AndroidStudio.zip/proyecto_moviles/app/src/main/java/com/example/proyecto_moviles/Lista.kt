package com.example.proyecto_moviles

import android.os.Bundle
import android.util.Log
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class Lista : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_lista)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        visualizarAsistencia()
    }

    fun visualizarAsistencia(){
        //val url= "http://192.168.100.38/Proyecto_moviles/lista.php"
        val url= "http://172.21.232.56/Proyecto_moviles/lista.php"
        val cola: RequestQueue = Volley.newRequestQueue(this)
        val request = JsonObjectRequest(
            Request.Method.GET, url, null,
            { response ->
                val success = response.getBoolean("success")
                if (success) {
                    val dataArray = response.getJSONArray("lista")
                    val contenedor= findViewById<LinearLayout>(R.id.container)

                    for (i in 0 until dataArray.length()) {
                        val item = dataArray.getJSONObject(i)
                        val id = item.getString("ID")
                        val nombre = item.getString("nombreCompleto")
                        val fecha = item.getString("Fecha")

                        // Crear un TextView dinámicamente para cada registro
                        val texto = TextView(this).apply {
                            text = "ID: $id\nNombre: $nombre\nFecha: $fecha"
                            textSize = 18f
                            setPadding(5, 16, 0, 16)

                        }
                        contenedor.addView(texto)
                    }
                } else {
                    val message = response.getString("message")
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            },
            { error ->
                Log.e("Error", error.toString())
            }
        )
        cola.add(request)
    }
}