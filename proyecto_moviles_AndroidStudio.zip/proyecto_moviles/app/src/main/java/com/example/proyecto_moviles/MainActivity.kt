package com.example.proyecto_moviles

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.android.volley.Request
import com.android.volley.Response
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    var id: EditText?=null
    var pass:EditText?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        id = findViewById(R.id.id)
        pass = findViewById(R.id.pass)
        // Obtener referencia al botón
        val btnRegister = findViewById<Button>(R.id.btnRegister)
        // Configurar evento para abrir la nueva actividad
        btnRegister.setOnClickListener {
            // Crear un Intent para abrir RegisterActivity
            val intent = Intent(this, Registro::class.java)
            startActivity(intent) // Iniciar la nueva actividad
        }
    }
    fun clickBtnIniciar(view: View){

        if (id?.text.isNullOrEmpty() || pass?.text.isNullOrEmpty()) {
            Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_LONG).show()
            return
        }

        //val url= "http://192.168.100.38/Proyecto_moviles/login.php"
        val url= "http://172.21.232.56/Proyecto_moviles/login.php"
        val col: RequestQueue = Volley.newRequestQueue(this)

        val validarPost = object : StringRequest(Request.Method.POST, url,
            Response.Listener<String> { response ->
                try{
                    // Depurar el contenido de la respuesta
                    //Toast.makeText(this, "Re: $response", Toast.LENGTH_LONG).show()
                    val jsonResponse = JSONObject(response)
                    val success = jsonResponse.getBoolean("success")
                    if(success){
                        val principal = Intent(this, Principal::class.java)
                        startActivity(principal) // Iniciar la nueva actividad
                    }else{
                        Toast.makeText(this, "Usuario o contraseña incorrectos", Toast.LENGTH_LONG).show()
                    }
                }catch (e : Exception){
                    Toast.makeText(this, "Error en los datos", Toast.LENGTH_LONG).show()
                }
            }, Response.ErrorListener { error ->
                Toast.makeText(this, "Error $error", Toast.LENGTH_LONG).show()
            }
        ) {
            override fun getParams(): Map<String, String>? {
                return mapOf(
                    "ID" to id?.text.toString(),
                    "pass" to pass?.text.toString()
                )
            }
        }
        col.add(validarPost)
    }

}